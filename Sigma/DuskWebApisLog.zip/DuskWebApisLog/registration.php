<?php
/*
 * Copyright © Sigma Infosolutions. All rights reserved.
 * See LICENSE for license details.
 */

use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(ComponentRegistrar::MODULE, 'Sigma_DuskWebApisLog', __DIR__);
